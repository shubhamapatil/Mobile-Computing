package com.notificationman.library.extensions

class NotificationManNotFiredException(warning: String) : Exception(warning)